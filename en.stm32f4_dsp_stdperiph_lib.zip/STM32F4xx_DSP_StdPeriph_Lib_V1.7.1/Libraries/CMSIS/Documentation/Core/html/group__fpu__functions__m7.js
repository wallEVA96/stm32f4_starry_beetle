var group__fpu__functions__m7 =
[
    [ "SCB_GetFPUType", "group__fpu__functions__m7.html#ga6bcad99ce80a0e7e4ddc6f2379081756", null ]
];