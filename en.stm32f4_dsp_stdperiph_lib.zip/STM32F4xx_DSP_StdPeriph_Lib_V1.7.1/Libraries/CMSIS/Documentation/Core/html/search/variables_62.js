var searchData=
[
  ['b',['b',['../union_a_p_s_r___type.html#a7dbc79a057ded4b11ca5323fc2d5ab14',1,'APSR_Type::b()'],['../union_i_p_s_r___type.html#add0d6497bd50c25569ea22b48a03ec50',1,'IPSR_Type::b()'],['../unionx_p_s_r___type.html#a3b1063bb5cdad67e037cba993b693b70',1,'xPSR_Type::b()'],['../union_c_o_n_t_r_o_l___type.html#adc6a38ab2980d0e9577b5a871da14eb9',1,'CONTROL_Type::b()']]],
  ['bfar',['BFAR',['../struct_s_c_b___type.html#a31f79afe86c949c9862e7d5fce077c3a',1,'SCB_Type']]]
];
